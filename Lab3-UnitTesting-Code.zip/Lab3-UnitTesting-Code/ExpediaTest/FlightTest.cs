using System;
using Expedia;
using NUnit.Framework;

namespace ExpediaTest
{
    [TestFixture()]
    public class FlightTest
    {
        private readonly DateTime sampleFlightStart = new DateTime(2010, 7, 10);
        private readonly DateTime sampleFlightEnd = new DateTime(2010, 7, 20);
        private readonly int sampleMiles = 500;

        private readonly DateTime twentyDayFlightStart = new DateTime(2010, 7, 10);
        private readonly DateTime twentyDayFlightEnd = new DateTime(2010, 7, 30);

        private readonly DateTime oneDayFlightStart = new DateTime(2010, 7, 1);
        private readonly DateTime oneDayFlightEnd = new DateTime(2010, 7, 2);

        private readonly DateTime fiveDayFlightStart = new DateTime(2010, 7, 1);
        private readonly DateTime fiveDayFlightEnd = new DateTime(2010, 7, 6);

        [Test()]
        public void TestThatFlightInitializes()
        {
            var target = new Flight(sampleFlightStart, sampleFlightEnd, sampleMiles);
            Assert.NotNull(target);
        }

        [Test()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestThatStartDateisBeforeEndDate()
        {
            new Flight(sampleFlightEnd, sampleFlightStart, sampleMiles);
        }

        [Test()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestThatMilesArePositive()
        {
            new Flight(sampleFlightStart, sampleFlightEnd, -50);
        }

        [Test()]
        public void TestBasePriceForTenDayFlight()
        {
            var target = new Flight(sampleFlightStart, sampleFlightEnd, sampleMiles);
            Assert.AreEqual(400, target.getBasePrice());
        }

        [Test()]
        public void TestBasePriceForTwentyDayFlight()
        {
            var target = new Flight(twentyDayFlightStart, twentyDayFlightEnd, sampleMiles);
            Assert.AreEqual(600, target.getBasePrice());
        }

        [Test()]
        public void TestBasePriceForOneDayFlight()
        {
            var target = new Flight(oneDayFlightStart, oneDayFlightEnd, sampleMiles);
            Assert.AreEqual(220, target.getBasePrice());
        }

        [Test()]
        public void TestBasePriceForFiveDayFlight()
        {
            var target = new Flight(fiveDayFlightStart, fiveDayFlightEnd, sampleMiles);
            Assert.AreEqual(300, target.getBasePrice());
        }
    }
}
