
using System;
using System.Collections.Generic;
using NUnit.Framework;
using Expedia;

namespace ExpediaTest
{
	[TestFixture()]
	public class BookingTest
	{
	}
}
