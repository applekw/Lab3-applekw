
using System;

namespace Expedia
{
	public interface Booking
	{
		double getBasePrice();
	}
}
